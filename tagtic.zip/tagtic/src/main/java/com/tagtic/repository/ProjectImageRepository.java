package com.tagtic.repository;

import com.tagtic.entity.ProjectImage;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.UUID;

public interface ProjectImageRepository extends JpaRepository<ProjectImage, UUID> {
    Page<ProjectImage> findByProjectId(UUID projectId, Pageable pageable);
}
