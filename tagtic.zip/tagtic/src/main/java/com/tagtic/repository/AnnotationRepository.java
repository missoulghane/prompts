package com.tagtic.repository;

import com.tagtic.entity.Annotation;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.UUID;

public interface AnnotationRepository extends JpaRepository<Annotation, UUID> {
    Page<Annotation> findByProjectId(UUID projectId, Pageable pageable);
    List<Annotation> findByProjectIdAndImageId(UUID projectId, UUID imageId);
}
