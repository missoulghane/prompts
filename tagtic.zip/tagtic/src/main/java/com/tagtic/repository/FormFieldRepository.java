package com.tagtic.repository;

import com.tagtic.entity.FormField;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.UUID;

public interface FormFieldRepository extends JpaRepository<FormField, UUID> {
    List<FormField> findByFormIdOrderByOrderIndexAsc(UUID formId);
}
