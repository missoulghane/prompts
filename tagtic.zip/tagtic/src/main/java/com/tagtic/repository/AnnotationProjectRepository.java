package com.tagtic.repository;

import com.tagtic.entity.AnnotationProject;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.UUID;

public interface AnnotationProjectRepository extends JpaRepository<AnnotationProject, UUID> {
}
