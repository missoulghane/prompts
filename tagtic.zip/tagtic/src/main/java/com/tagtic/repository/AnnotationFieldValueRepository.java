package com.tagtic.repository;

import com.tagtic.entity.AnnotationFieldValue;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.UUID;

public interface AnnotationFieldValueRepository extends JpaRepository<AnnotationFieldValue, UUID> {
    List<AnnotationFieldValue> findByAnnotationId(UUID annotationId);
}
