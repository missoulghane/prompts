package com.tagtic.repository;

import com.tagtic.entity.AnnotationForm;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.UUID;

public interface AnnotationFormRepository extends JpaRepository<AnnotationForm, UUID> {
}
