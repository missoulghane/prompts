package com.tagtic.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class OpenApiConfig {

    @Bean
    public OpenAPI tagticOpenAPI() {
        return new OpenAPI().info(new Info()
                .title("TAGTIC - Image Annotation API")
                .description("Plateforme d'Annotation d'Images")
                .version("1.0.0"));
    }
}
