package com.tagtic.service;

import com.tagtic.dto.request.CreateProjectRequest;
import com.tagtic.dto.request.UpdateProjectRequest;
import com.tagtic.entity.AnnotationForm;
import com.tagtic.entity.AnnotationProject;
import com.tagtic.entity.ProjectStatus;
import com.tagtic.exception.ResourceNotFoundException;
import com.tagtic.repository.AnnotationFormRepository;
import com.tagtic.repository.AnnotationProjectRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class ProjectService {

    private final AnnotationProjectRepository projectRepository;
    private final AnnotationFormRepository formRepository;

    @Transactional
    public AnnotationProject create(CreateProjectRequest request) {
        AnnotationProject project = AnnotationProject.builder()
                .title(request.getTitle())
                .description(request.getDescription())
                .createdBy(request.getCreatedBy())
                .status(ProjectStatus.DRAFT)
                .build();
        return projectRepository.save(project);
    }

    @Transactional(readOnly = true)
    public List<AnnotationProject> findAll() {
        return projectRepository.findAll();
    }

    @Transactional(readOnly = true)
    public AnnotationProject findById(UUID id) {
        return projectRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "PROJECT_NOT_FOUND", "Project not found"));
    }

    @Transactional
    public AnnotationProject update(UUID id, UpdateProjectRequest request) {
        AnnotationProject project = findById(id);
        if (request.getTitle() != null) {
            project.setTitle(request.getTitle());
        }
        if (request.getDescription() != null) {
            project.setDescription(request.getDescription());
        }
        if (request.getStatus() != null) {
            project.setStatus(request.getStatus());
        }
        return projectRepository.save(project);
    }

    @Transactional
    public void delete(UUID id) {
        AnnotationProject project = findById(id);
        projectRepository.delete(project);
    }

    @Transactional
    public AnnotationProject linkForm(UUID projectId, UUID formId) {
        AnnotationProject project = findById(projectId);
        AnnotationForm form = formRepository.findById(formId)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "FORM_NOT_FOUND", "Form not found"));
        project.setFormId(form.getId());
        if (project.getStatus() == ProjectStatus.DRAFT) {
            project.setStatus(ProjectStatus.READY);
        }
        return projectRepository.save(project);
    }
}
