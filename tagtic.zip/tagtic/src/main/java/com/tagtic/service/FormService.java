package com.tagtic.service;

import com.tagtic.dto.request.AddFieldRequest;
import com.tagtic.dto.request.CreateFormRequest;
import com.tagtic.entity.AnnotationForm;
import com.tagtic.entity.FormField;
import com.tagtic.exception.ResourceNotFoundException;
import com.tagtic.repository.AnnotationFormRepository;
import com.tagtic.repository.FormFieldRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class FormService {

    private final AnnotationFormRepository formRepository;
    private final FormFieldRepository fieldRepository;

    @Transactional
    public AnnotationForm create(CreateFormRequest request) {
        AnnotationForm form = AnnotationForm.builder()
                .title(request.getTitle())
                .description(request.getDescription())
                .version(request.getVersion() != null ? request.getVersion() : 1)
                .createdBy(request.getCreatedBy())
                .build();
        return formRepository.save(form);
    }

    @Transactional(readOnly = true)
    public AnnotationForm findById(UUID id) {
        return formRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "FORM_NOT_FOUND", "Form not found"));
    }

    @Transactional
    public List<FormField> addFields(UUID formId, List<AddFieldRequest> requests) {
        AnnotationForm form = findById(formId);
        List<FormField> created = new ArrayList<>();
        int nextIndex = fieldRepository.findByFormIdOrderByOrderIndexAsc(formId).size();
        for (AddFieldRequest req : requests) {
            FormField field = FormField.builder()
                    .formId(form.getId())
                    .name(req.getName())
                    .label(req.getLabel())
                    .type(req.getType())
                    .required(req.getRequired() != null ? req.getRequired() : false)
                    .orderIndex(req.getOrderIndex() != null ? req.getOrderIndex() : nextIndex++)
                    .defaultValue(req.getDefaultValue())
                    .jsonMappingKey(req.getJsonMappingKey())
                    .validationRules(req.getValidationRules())
                    .build();
            created.add(fieldRepository.save(field));
        }
        return created;
    }

    @Transactional(readOnly = true)
    public List<FormField> getFields(UUID formId) {
        findById(formId);
        return fieldRepository.findByFormIdOrderByOrderIndexAsc(formId);
    }
}
