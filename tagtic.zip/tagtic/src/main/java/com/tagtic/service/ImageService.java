package com.tagtic.service;

import com.tagtic.dto.request.CreateImageRequest;
import com.tagtic.entity.ProjectImage;
import com.tagtic.exception.ResourceNotFoundException;
import com.tagtic.repository.ProjectImageRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.UUID;

@Service
@RequiredArgsConstructor
public class ImageService {

    private final ProjectImageRepository imageRepository;
    private final ProjectService projectService;

    @Transactional
    public ProjectImage addImage(UUID projectId, CreateImageRequest request) {
        projectService.findById(projectId);
        ProjectImage image = ProjectImage.builder()
                .projectId(projectId)
                .s3Url(request.getS3Url())
                .metadata(request.getMetadata())
                .build();
        return imageRepository.save(image);
    }

    @Transactional(readOnly = true)
    public Page<ProjectImage> listByProject(UUID projectId, Pageable pageable) {
        projectService.findById(projectId);
        return imageRepository.findByProjectId(projectId, pageable);
    }

    @Transactional(readOnly = true)
    public ProjectImage findById(UUID imageId) {
        return imageRepository.findById(imageId)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "IMAGE_NOT_FOUND", "Image not found"));
    }
}
