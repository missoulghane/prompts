package com.tagtic.service;

import com.tagtic.dto.request.CreateAnnotationRequest;
import com.tagtic.dto.response.AnnotationFormResponse;
import com.tagtic.dto.response.PrefilledFieldResponse;
import com.tagtic.entity.*;
import com.tagtic.exception.BusinessException;
import com.tagtic.exception.ResourceNotFoundException;
import com.tagtic.repository.AnnotationFieldValueRepository;
import com.tagtic.repository.AnnotationRepository;
import com.tagtic.repository.FormFieldRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class AnnotationService {

    private final AnnotationRepository annotationRepository;
    private final AnnotationFieldValueRepository fieldValueRepository;
    private final FormFieldRepository fieldRepository;
    private final ProjectService projectService;
    private final ImageService imageService;

    /**
     * Builds the project form prefilled from the image metadata.
     */
    @Transactional(readOnly = true)
    public AnnotationFormResponse buildPrefilledForm(UUID projectId, UUID imageId) {
        AnnotationProject project = projectService.findById(projectId);
        ProjectImage image = imageService.findById(imageId);

        if (!image.getProjectId().equals(projectId)) {
            throw new BusinessException("IMAGE_PROJECT_MISMATCH",
                    "Image does not belong to this project");
        }
        if (project.getFormId() == null) {
            throw new BusinessException("NO_FORM_LINKED",
                    "No form is linked to this project");
        }

        List<FormField> fields = fieldRepository
                .findByFormIdOrderByOrderIndexAsc(project.getFormId());
        Map<String, Object> metadata = image.getMetadata();

        List<PrefilledFieldResponse> prefilled = new ArrayList<>();
        for (FormField field : fields) {
            Object value = null;
            boolean autoFilled = false;
            String sourceKey = null;

            if (field.getJsonMappingKey() != null && !field.getJsonMappingKey().isBlank()) {
                Object resolved = MetadataResolver.resolve(metadata, field.getJsonMappingKey());
                if (resolved != null) {
                    value = coerce(resolved, field.getType());
                    autoFilled = true;
                    sourceKey = field.getJsonMappingKey();
                }
            }
            if (value == null && field.getDefaultValue() != null) {
                value = coerce(field.getDefaultValue(), field.getType());
            }

            prefilled.add(PrefilledFieldResponse.builder()
                    .formFieldId(field.getId())
                    .name(field.getName())
                    .label(field.getLabel())
                    .type(field.getType())
                    .required(field.getRequired())
                    .value(value)
                    .autoFilled(autoFilled)
                    .sourceMetadataKey(sourceKey)
                    .build());
        }

        return AnnotationFormResponse.builder()
                .imageId(imageId)
                .formId(project.getFormId())
                .fields(prefilled)
                .build();
    }

    @Transactional
    public Annotation save(UUID projectId, CreateAnnotationRequest request) {
        AnnotationProject project = projectService.findById(projectId);
        ProjectImage image = imageService.findById(request.getImageId());

        if (!image.getProjectId().equals(projectId)) {
            throw new BusinessException("IMAGE_PROJECT_MISMATCH",
                    "Image does not belong to this project");
        }
        if (project.getFormId() == null) {
            throw new BusinessException("NO_FORM_LINKED",
                    "No form is linked to this project");
        }

        Map<UUID, FormField> fieldsById = fieldRepository
                .findByFormIdOrderByOrderIndexAsc(project.getFormId()).stream()
                .collect(Collectors.toMap(FormField::getId, f -> f));

        Map<String, Object> metadata = image.getMetadata();

        // Persist annotation
        Annotation annotation = Annotation.builder()
                .projectId(projectId)
                .imageId(request.getImageId())
                .annotatedBy(request.getAnnotatedBy())
                .status(AnnotationStatus.PENDING)
                .build();
        annotation = annotationRepository.save(annotation);

        // Validate required fields are provided
        Map<UUID, Object> submitted = new java.util.HashMap<>();
        if (request.getFields() != null) {
            for (CreateAnnotationRequest.FieldValueRequest fv : request.getFields()) {
                submitted.put(fv.getFormFieldId(), fv.getValue());
            }
        }
        for (FormField field : fieldsById.values()) {
            if (Boolean.TRUE.equals(field.getRequired())
                    && submitted.get(field.getId()) == null) {
                throw new BusinessException("REQUIRED_FIELD_MISSING",
                        "Required field missing: " + field.getName());
            }
        }

        // Persist field values with snapshots
        if (request.getFields() != null) {
            for (CreateAnnotationRequest.FieldValueRequest fv : request.getFields()) {
                FormField field = fieldsById.get(fv.getFormFieldId());
                if (field == null) {
                    throw new ResourceNotFoundException("FIELD_NOT_FOUND",
                            "Form field not found: " + fv.getFormFieldId());
                }

                Object value = fv.getValue();
                boolean autoFilled = false;
                String sourceKey = null;

                // Determine if value matches the metadata auto-fill source
                if (field.getJsonMappingKey() != null && !field.getJsonMappingKey().isBlank()) {
                    Object resolved = MetadataResolver.resolve(metadata, field.getJsonMappingKey());
                    if (resolved != null && value != null
                            && coerce(resolved, field.getType()).equals(coerce(value, field.getType()))) {
                        autoFilled = true;
                        sourceKey = field.getJsonMappingKey();
                    }
                }

                AnnotationFieldValue afv = AnnotationFieldValue.builder()
                        .annotationId(annotation.getId())
                        .formFieldId(field.getId())
                        .fieldName(field.getName())
                        .fieldLabel(field.getLabel())
                        .fieldType(field.getType())
                        .value(coerce(value, field.getType()))
                        .autoFilled(autoFilled)
                        .sourceMetadataKey(sourceKey)
                        .build();
                fieldValueRepository.save(afv);
            }
        }

        return annotation;
    }

    @Transactional(readOnly = true)
    public List<AnnotationFieldValue> getValues(UUID annotationId) {
        return fieldValueRepository.findByAnnotationId(annotationId);
    }

    @Transactional(readOnly = true)
    public org.springframework.data.domain.Page<Annotation> listByProject(
            UUID projectId, org.springframework.data.domain.Pageable pageable) {
        projectService.findById(projectId);
        return annotationRepository.findByProjectId(projectId, pageable);
    }

    @Transactional(readOnly = true)
    public List<Annotation> listByImage(UUID projectId, UUID imageId) {
        projectService.findById(projectId);
        return annotationRepository.findByProjectIdAndImageId(projectId, imageId);
    }

    /**
     * Coerces a raw value to the target field type.
     */
    private Object coerce(Object raw, FieldType type) {
        if (raw == null) {
            return null;
        }
        try {
            return switch (type) {
                case NUMBER -> raw instanceof Number n ? n : Double.valueOf(raw.toString());
                case BOOLEAN -> raw instanceof Boolean b ? b : Boolean.valueOf(raw.toString());
                case TEXT, DATE, SELECT -> raw.toString();
            };
        } catch (NumberFormatException e) {
            throw new BusinessException("INVALID_VALUE_TYPE",
                    "Value '" + raw + "' is not a valid " + type);
        }
    }
}
