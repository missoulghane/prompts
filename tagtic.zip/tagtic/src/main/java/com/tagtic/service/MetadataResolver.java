package com.tagtic.service;

import java.util.Map;

/**
 * Resolves a metadata key against a JSON metadata map.
 * Supports nested dotted keys, e.g. "extractions.amount".
 */
public final class MetadataResolver {

    private MetadataResolver() {
    }

    @SuppressWarnings("unchecked")
    public static Object resolve(Map<String, Object> metadata, String key) {
        if (metadata == null || key == null || key.isBlank()) {
            return null;
        }
        Object current = metadata;
        for (String part : key.split("\\.")) {
            if (!(current instanceof Map)) {
                return null;
            }
            current = ((Map<String, Object>) current).get(part);
            if (current == null) {
                return null;
            }
        }
        return current;
    }
}
