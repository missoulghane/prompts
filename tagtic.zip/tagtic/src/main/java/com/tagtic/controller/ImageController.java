package com.tagtic.controller;

import com.tagtic.dto.request.CreateImageRequest;
import com.tagtic.dto.response.ApiResponse;
import com.tagtic.dto.response.ImageResponse;
import com.tagtic.dto.response.PageResponse;
import com.tagtic.mapper.ImageMapper;
import com.tagtic.service.ImageService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.UUID;

@RestController
@RequiredArgsConstructor
@Tag(name = "Images")
public class ImageController {

    private final ImageService imageService;
    private final ImageMapper imageMapper;

    @PostMapping("/api/projects/{projectId}/images")
    @Operation(summary = "Add an image to a project")
    public ResponseEntity<ApiResponse<ImageResponse>> addImage(
            @PathVariable UUID projectId,
            @Valid @RequestBody CreateImageRequest request) {
        ImageResponse body = imageMapper.toResponse(
                imageService.addImage(projectId, request));
        return ResponseEntity.status(HttpStatus.CREATED).body(ApiResponse.ok(body));
    }

    @GetMapping("/api/projects/{projectId}/images")
    @Operation(summary = "List project images (paginated)")
    public ApiResponse<PageResponse<ImageResponse>> listImages(
            @PathVariable UUID projectId,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size) {
        Pageable pageable = PageRequest.of(page, size);
        PageResponse<ImageResponse> body = PageResponse.from(
                imageService.listByProject(projectId, pageable), imageMapper::toResponse);
        return ApiResponse.ok(body);
    }

    @GetMapping("/api/images/{imageId}")
    @Operation(summary = "Get an image")
    public ApiResponse<ImageResponse> getImage(@PathVariable UUID imageId) {
        return ApiResponse.ok(imageMapper.toResponse(imageService.findById(imageId)));
    }
}
