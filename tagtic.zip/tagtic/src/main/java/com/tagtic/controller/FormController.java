package com.tagtic.controller;

import com.tagtic.dto.request.AddFieldRequest;
import com.tagtic.dto.request.CreateFormRequest;
import com.tagtic.dto.response.ApiResponse;
import com.tagtic.dto.response.FieldResponse;
import com.tagtic.dto.response.FormResponse;
import com.tagtic.mapper.FormMapper;
import com.tagtic.service.FormService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/forms")
@RequiredArgsConstructor
@Tag(name = "Forms")
public class FormController {

    private final FormService formService;
    private final FormMapper formMapper;

    @PostMapping
    @Operation(summary = "Create a form")
    public ResponseEntity<ApiResponse<FormResponse>> create(
            @Valid @RequestBody CreateFormRequest request) {
        FormResponse body = formMapper.toResponse(formService.create(request));
        return ResponseEntity.status(HttpStatus.CREATED).body(ApiResponse.ok(body));
    }

    @PostMapping("/{formId}/fields")
    @Operation(summary = "Add fields to a form")
    public ResponseEntity<ApiResponse<List<FieldResponse>>> addFields(
            @PathVariable UUID formId,
            @Valid @RequestBody List<AddFieldRequest> requests) {
        List<FieldResponse> body = formService.addFields(formId, requests).stream()
                .map(formMapper::toResponse).toList();
        return ResponseEntity.status(HttpStatus.CREATED).body(ApiResponse.ok(body));
    }

    @GetMapping("/{formId}/fields")
    @Operation(summary = "List form fields")
    public ApiResponse<List<FieldResponse>> getFields(@PathVariable UUID formId) {
        List<FieldResponse> body = formService.getFields(formId).stream()
                .map(formMapper::toResponse).toList();
        return ApiResponse.ok(body);
    }
}
