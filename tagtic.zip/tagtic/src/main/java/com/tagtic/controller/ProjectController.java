package com.tagtic.controller;

import com.tagtic.dto.request.CreateProjectRequest;
import com.tagtic.dto.request.UpdateProjectRequest;
import com.tagtic.dto.response.ApiResponse;
import com.tagtic.dto.response.ProjectResponse;
import com.tagtic.mapper.ProjectMapper;
import com.tagtic.service.ProjectService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/projects")
@RequiredArgsConstructor
@Tag(name = "Projects")
public class ProjectController {

    private final ProjectService projectService;
    private final ProjectMapper projectMapper;

    @PostMapping
    @Operation(summary = "Create a project")
    public ResponseEntity<ApiResponse<ProjectResponse>> create(
            @Valid @RequestBody CreateProjectRequest request) {
        ProjectResponse body = projectMapper.toResponse(projectService.create(request));
        return ResponseEntity.status(HttpStatus.CREATED).body(ApiResponse.ok(body));
    }

    @GetMapping
    @Operation(summary = "List all projects")
    public ApiResponse<List<ProjectResponse>> list() {
        List<ProjectResponse> body = projectService.findAll().stream()
                .map(projectMapper::toResponse).toList();
        return ApiResponse.ok(body);
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get a project")
    public ApiResponse<ProjectResponse> get(@PathVariable UUID id) {
        return ApiResponse.ok(projectMapper.toResponse(projectService.findById(id)));
    }

    @PutMapping("/{id}")
    @Operation(summary = "Update a project")
    public ApiResponse<ProjectResponse> update(
            @PathVariable UUID id, @RequestBody UpdateProjectRequest request) {
        return ApiResponse.ok(projectMapper.toResponse(projectService.update(id, request)));
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Delete a project")
    public ApiResponse<Void> delete(@PathVariable UUID id) {
        projectService.delete(id);
        return ApiResponse.ok(null);
    }

    @PutMapping("/{projectId}/form/{formId}")
    @Operation(summary = "Link a form to a project")
    public ApiResponse<ProjectResponse> linkForm(
            @PathVariable UUID projectId, @PathVariable UUID formId) {
        return ApiResponse.ok(projectMapper.toResponse(
                projectService.linkForm(projectId, formId)));
    }
}
