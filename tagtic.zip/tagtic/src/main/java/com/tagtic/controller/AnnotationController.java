package com.tagtic.controller;

import com.tagtic.dto.request.CreateAnnotationRequest;
import com.tagtic.dto.response.AnnotationFormResponse;
import com.tagtic.dto.response.AnnotationResponse;
import com.tagtic.dto.response.ApiResponse;
import com.tagtic.dto.response.PageResponse;
import com.tagtic.entity.Annotation;
import com.tagtic.mapper.AnnotationMapper;
import com.tagtic.service.AnnotationService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/projects/{projectId}")
@RequiredArgsConstructor
@Tag(name = "Annotations")
public class AnnotationController {

    private final AnnotationService annotationService;
    private final AnnotationMapper annotationMapper;

    @GetMapping("/images/{imageId}/annotation-form")
    @Operation(summary = "Get the prefilled annotation form for an image")
    public ApiResponse<AnnotationFormResponse> getPrefilledForm(
            @PathVariable UUID projectId, @PathVariable UUID imageId) {
        return ApiResponse.ok(annotationService.buildPrefilledForm(projectId, imageId));
    }

    @PostMapping("/annotations")
    @Operation(summary = "Save an annotation")
    public ResponseEntity<ApiResponse<AnnotationResponse>> save(
            @PathVariable UUID projectId,
            @Valid @RequestBody CreateAnnotationRequest request) {
        Annotation annotation = annotationService.save(projectId, request);
        AnnotationResponse body = annotationMapper.toResponse(
                annotation, annotationService.getValues(annotation.getId()));
        return ResponseEntity.status(HttpStatus.CREATED).body(ApiResponse.ok(body));
    }

    @GetMapping("/annotations")
    @Operation(summary = "List project annotations (paginated)")
    public ApiResponse<PageResponse<AnnotationResponse>> list(
            @PathVariable UUID projectId,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size) {
        Pageable pageable = PageRequest.of(page, size);
        PageResponse<AnnotationResponse> body = PageResponse.from(
                annotationService.listByProject(projectId, pageable),
                a -> annotationMapper.toResponse(a, annotationService.getValues(a.getId())));
        return ApiResponse.ok(body);
    }

    @GetMapping("/images/{imageId}/annotations")
    @Operation(summary = "Get annotations for an image")
    public ApiResponse<List<AnnotationResponse>> listByImage(
            @PathVariable UUID projectId, @PathVariable UUID imageId) {
        List<AnnotationResponse> body = annotationService.listByImage(projectId, imageId).stream()
                .map(a -> annotationMapper.toResponse(a, annotationService.getValues(a.getId())))
                .toList();
        return ApiResponse.ok(body);
    }
}
