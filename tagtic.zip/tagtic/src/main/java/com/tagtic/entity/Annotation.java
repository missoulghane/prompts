package com.tagtic.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.Instant;
import java.util.UUID;

@Entity
@Table(name = "annotation")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Annotation {

    @Id
    @GeneratedValue
    private UUID id;

    @Column(nullable = false)
    private UUID projectId;

    @Column(nullable = false)
    private UUID imageId;

    private String annotatedBy;

    @Column(nullable = false, updatable = false)
    private Instant annotatedAt;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private AnnotationStatus status;

    @PrePersist
    void onCreate() {
        this.annotatedAt = Instant.now();
        if (this.status == null) {
            this.status = AnnotationStatus.PENDING;
        }
    }
}
