package com.tagtic.entity;

import io.hypersistence.utils.hibernate.type.json.JsonType;
import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.Type;

import java.util.Map;
import java.util.UUID;

@Entity
@Table(name = "form_field")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class FormField {

    @Id
    @GeneratedValue
    private UUID id;

    @Column(nullable = false)
    private UUID formId;

    @Column(nullable = false)
    private String name;

    private String label;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private FieldType type;

    private Boolean required;

    private Integer orderIndex;

    private String defaultValue;

    /** Metadata key used for auto-fill prefill. */
    private String jsonMappingKey;

    /** Dynamic validation rules stored as JSON. */
    @Type(JsonType.class)
    @Column(columnDefinition = "json")
    private Map<String, Object> validationRules;

    @PrePersist
    void onCreate() {
        if (this.required == null) {
            this.required = false;
        }
    }
}
