package com.tagtic.entity;

public enum ProjectStatus {
    DRAFT, READY, IN_PROGRESS, COMPLETED, ARCHIVED
}
