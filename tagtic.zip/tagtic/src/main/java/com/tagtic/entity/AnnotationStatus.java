package com.tagtic.entity;

public enum AnnotationStatus {
    PENDING, VALIDATED, REJECTED
}
