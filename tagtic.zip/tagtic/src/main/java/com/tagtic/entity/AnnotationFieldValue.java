package com.tagtic.entity;

import io.hypersistence.utils.hibernate.type.json.JsonType;
import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.Type;

import java.time.Instant;
import java.util.UUID;

@Entity
@Table(name = "annotation_field_value")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AnnotationFieldValue {

    @Id
    @GeneratedValue
    private UUID id;

    @Column(nullable = false)
    private UUID annotationId;

    @Column(nullable = false)
    private UUID formFieldId;

    /** Snapshot of the technical field name. */
    private String fieldName;

    /** Snapshot of the displayed label. */
    private String fieldLabel;

    /** Snapshot of the field type. */
    @Enumerated(EnumType.STRING)
    private FieldType fieldType;

    /** Saved value, stored as JSON to support any type (text/number/boolean...). */
    @Type(JsonType.class)
    @Column(columnDefinition = "json")
    private Object value;

    private Boolean autoFilled;

    private String sourceMetadataKey;

    @Column(nullable = false, updatable = false)
    private Instant createdAt;

    @PrePersist
    void onCreate() {
        this.createdAt = Instant.now();
        if (this.autoFilled == null) {
            this.autoFilled = false;
        }
    }
}
