package com.tagtic.entity;

public enum FieldType {
    TEXT, NUMBER, BOOLEAN, DATE, SELECT
}
