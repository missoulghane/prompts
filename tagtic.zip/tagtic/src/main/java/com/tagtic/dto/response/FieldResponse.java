package com.tagtic.dto.response;

import com.tagtic.entity.FieldType;
import lombok.Builder;
import lombok.Data;

import java.util.Map;
import java.util.UUID;

@Data
@Builder
public class FieldResponse {
    private UUID id;
    private UUID formId;
    private String name;
    private String label;
    private FieldType type;
    private Boolean required;
    private Integer orderIndex;
    private String defaultValue;
    private String jsonMappingKey;
    private Map<String, Object> validationRules;
}
