package com.tagtic.dto.request;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

import java.util.Map;

@Data
public class CreateImageRequest {
    @NotBlank
    private String s3Url;
    private Map<String, Object> metadata;
}
