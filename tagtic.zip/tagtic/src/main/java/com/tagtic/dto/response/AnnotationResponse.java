package com.tagtic.dto.response;

import com.tagtic.entity.AnnotationStatus;
import lombok.Builder;
import lombok.Data;

import java.time.Instant;
import java.util.List;
import java.util.UUID;

@Data
@Builder
public class AnnotationResponse {
    private UUID id;
    private UUID projectId;
    private UUID imageId;
    private String annotatedBy;
    private Instant annotatedAt;
    private AnnotationStatus status;
    private List<FieldValueResponse> fields;
}
