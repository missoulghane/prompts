package com.tagtic.dto.response;

import com.tagtic.entity.ProjectStatus;
import lombok.Builder;
import lombok.Data;

import java.time.Instant;
import java.util.UUID;

@Data
@Builder
public class ProjectResponse {
    private UUID id;
    private String title;
    private String description;
    private ProjectStatus status;
    private String createdBy;
    private Instant createdAt;
    private Instant updatedAt;
    private UUID formId;
}
