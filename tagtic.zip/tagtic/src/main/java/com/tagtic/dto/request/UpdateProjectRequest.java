package com.tagtic.dto.request;

import com.tagtic.entity.ProjectStatus;
import lombok.Data;

@Data
public class UpdateProjectRequest {
    private String title;
    private String description;
    private ProjectStatus status;
}
