package com.tagtic.dto.response;

import com.tagtic.entity.FieldType;
import lombok.Builder;
import lombok.Data;

import java.time.Instant;
import java.util.UUID;

@Data
@Builder
public class FieldValueResponse {
    private UUID id;
    private UUID formFieldId;
    private String fieldName;
    private String fieldLabel;
    private FieldType fieldType;
    private Object value;
    private Boolean autoFilled;
    private String sourceMetadataKey;
    private Instant createdAt;
}
