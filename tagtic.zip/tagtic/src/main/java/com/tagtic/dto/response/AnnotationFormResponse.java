package com.tagtic.dto.response;

import lombok.Builder;
import lombok.Data;

import java.util.List;
import java.util.UUID;

@Data
@Builder
public class AnnotationFormResponse {
    private UUID imageId;
    private UUID formId;
    private List<PrefilledFieldResponse> fields;
}
