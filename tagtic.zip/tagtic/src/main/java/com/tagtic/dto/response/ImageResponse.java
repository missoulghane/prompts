package com.tagtic.dto.response;

import lombok.Builder;
import lombok.Data;

import java.time.Instant;
import java.util.Map;
import java.util.UUID;

@Data
@Builder
public class ImageResponse {
    private UUID id;
    private UUID projectId;
    private String s3Url;
    private Map<String, Object> metadata;
    private Instant createdAt;
}
