package com.tagtic.dto.request;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.util.List;
import java.util.UUID;

@Data
public class CreateAnnotationRequest {
    @NotNull
    private UUID imageId;
    private String annotatedBy;
    @Valid
    private List<FieldValueRequest> fields;

    @Data
    public static class FieldValueRequest {
        @NotNull
        private UUID formFieldId;
        private Object value;
    }
}
