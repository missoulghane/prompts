package com.tagtic.dto.request;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class CreateProjectRequest {
    @NotBlank
    private String title;
    private String description;
    private String createdBy;
}
