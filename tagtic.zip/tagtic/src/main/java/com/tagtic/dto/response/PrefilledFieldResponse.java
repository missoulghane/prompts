package com.tagtic.dto.response;

import com.tagtic.entity.FieldType;
import lombok.Builder;
import lombok.Data;

import java.util.UUID;

@Data
@Builder
public class PrefilledFieldResponse {
    private UUID formFieldId;
    private String name;
    private String label;
    private FieldType type;
    private Boolean required;
    private Object value;
    private Boolean autoFilled;
    private String sourceMetadataKey;
}
