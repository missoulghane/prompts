package com.tagtic.dto.request;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class CreateFormRequest {
    @NotBlank
    private String title;
    private String description;
    private Integer version;
    private String createdBy;
}
