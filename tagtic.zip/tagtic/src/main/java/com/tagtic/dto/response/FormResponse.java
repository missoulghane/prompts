package com.tagtic.dto.response;

import lombok.Builder;
import lombok.Data;

import java.time.Instant;
import java.util.UUID;

@Data
@Builder
public class FormResponse {
    private UUID id;
    private String title;
    private String description;
    private Integer version;
    private String createdBy;
    private Instant createdAt;
}
