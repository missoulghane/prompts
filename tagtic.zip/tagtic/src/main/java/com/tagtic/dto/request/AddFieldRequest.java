package com.tagtic.dto.request;

import com.tagtic.entity.FieldType;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.util.Map;

@Data
public class AddFieldRequest {
    @NotBlank
    private String name;
    private String label;
    @NotNull
    private FieldType type;
    private Boolean required;
    private Integer orderIndex;
    private String defaultValue;
    private String jsonMappingKey;
    private Map<String, Object> validationRules;
}
