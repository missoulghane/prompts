package com.tagtic.mapper;

import com.tagtic.dto.response.ProjectResponse;
import com.tagtic.entity.AnnotationProject;
import org.springframework.stereotype.Component;

@Component
public class ProjectMapper {
    public ProjectResponse toResponse(AnnotationProject p) {
        return ProjectResponse.builder()
                .id(p.getId())
                .title(p.getTitle())
                .description(p.getDescription())
                .status(p.getStatus())
                .createdBy(p.getCreatedBy())
                .createdAt(p.getCreatedAt())
                .updatedAt(p.getUpdatedAt())
                .formId(p.getFormId())
                .build();
    }
}
