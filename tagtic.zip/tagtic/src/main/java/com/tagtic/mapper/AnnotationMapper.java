package com.tagtic.mapper;

import com.tagtic.dto.response.AnnotationResponse;
import com.tagtic.dto.response.FieldValueResponse;
import com.tagtic.entity.Annotation;
import com.tagtic.entity.AnnotationFieldValue;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class AnnotationMapper {

    public FieldValueResponse toResponse(AnnotationFieldValue v) {
        return FieldValueResponse.builder()
                .id(v.getId())
                .formFieldId(v.getFormFieldId())
                .fieldName(v.getFieldName())
                .fieldLabel(v.getFieldLabel())
                .fieldType(v.getFieldType())
                .value(v.getValue())
                .autoFilled(v.getAutoFilled())
                .sourceMetadataKey(v.getSourceMetadataKey())
                .createdAt(v.getCreatedAt())
                .build();
    }

    public AnnotationResponse toResponse(Annotation a, List<AnnotationFieldValue> values) {
        return AnnotationResponse.builder()
                .id(a.getId())
                .projectId(a.getProjectId())
                .imageId(a.getImageId())
                .annotatedBy(a.getAnnotatedBy())
                .annotatedAt(a.getAnnotatedAt())
                .status(a.getStatus())
                .fields(values.stream().map(this::toResponse).toList())
                .build();
    }
}
