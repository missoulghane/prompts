package com.tagtic.mapper;

import com.tagtic.dto.response.ImageResponse;
import com.tagtic.entity.ProjectImage;
import org.springframework.stereotype.Component;

@Component
public class ImageMapper {
    public ImageResponse toResponse(ProjectImage img) {
        return ImageResponse.builder()
                .id(img.getId())
                .projectId(img.getProjectId())
                .s3Url(img.getS3Url())
                .metadata(img.getMetadata())
                .createdAt(img.getCreatedAt())
                .build();
    }
}
