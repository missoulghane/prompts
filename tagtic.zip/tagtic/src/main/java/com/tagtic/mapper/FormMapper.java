package com.tagtic.mapper;

import com.tagtic.dto.response.FieldResponse;
import com.tagtic.dto.response.FormResponse;
import com.tagtic.entity.AnnotationForm;
import com.tagtic.entity.FormField;
import org.springframework.stereotype.Component;

@Component
public class FormMapper {
    public FormResponse toResponse(AnnotationForm f) {
        return FormResponse.builder()
                .id(f.getId())
                .title(f.getTitle())
                .description(f.getDescription())
                .version(f.getVersion())
                .createdBy(f.getCreatedBy())
                .createdAt(f.getCreatedAt())
                .build();
    }

    public FieldResponse toResponse(FormField field) {
        return FieldResponse.builder()
                .id(field.getId())
                .formId(field.getFormId())
                .name(field.getName())
                .label(field.getLabel())
                .type(field.getType())
                .required(field.getRequired())
                .orderIndex(field.getOrderIndex())
                .defaultValue(field.getDefaultValue())
                .jsonMappingKey(field.getJsonMappingKey())
                .validationRules(field.getValidationRules())
                .build();
    }
}
