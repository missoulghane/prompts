package com.tagtic;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TagticApplication {
    public static void main(String[] args) {
        SpringApplication.run(TagticApplication.class, args);
    }
}
