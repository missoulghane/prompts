# TAGTIC — Plateforme d'Annotation d'Images

API REST Spring Boot (sans Spring Security) pour gérer des projets d'annotation
d'images : projets, formulaires dynamiques, images + métadonnées JSON,
préremplissage automatique, et traçabilité par champ.

## Stack

- Java 21, Spring Boot 3.3.x
- Spring Web, Spring Data JPA, Hibernate
- H2 (en mémoire, mode PostgreSQL)
- Bean Validation (`jakarta.validation`)
- Lombok
- OpenAPI / Swagger UI (springdoc)
- hypersistence-utils (support du type JSON Hibernate)

## Lancer

```bash
mvn spring-boot:run
```

L'API démarre sur `http://localhost:8080`.

- Swagger UI : `http://localhost:8080/swagger-ui.html`
- OpenAPI JSON : `http://localhost:8080/v3/api-docs`
- Console H2 : `http://localhost:8080/h2-console`
  (JDBC URL : `jdbc:h2:mem:tagtic`, user `sa`, mot de passe vide)

## Workflow

1. `POST /api/projects` — créer un projet
2. `POST /api/forms` — créer un formulaire
3. `POST /api/forms/{formId}/fields` — ajouter des champs (payload = tableau)
4. `PUT /api/projects/{projectId}/form/{formId}` — associer le formulaire au projet
5. `POST /api/projects/{projectId}/images` — ajouter une image (s3Url + metadata)
6. `GET /api/projects/{projectId}/images/{imageId}/annotation-form`
   — récupérer le formulaire prérempli depuis les métadonnées de l'image
7. `POST /api/projects/{projectId}/annotations` — sauvegarder l'annotation

## Préremplissage automatique

Chaque champ peut définir un `jsonMappingKey` pointant vers une clé des
métadonnées de l'image. Les clés imbriquées sont supportées via la notation
pointée, ex. `extractions.amount`.

Lors de la récupération du formulaire prérempli, la valeur est extraite des
métadonnées, convertie selon le type du champ (`NUMBER`, `BOOLEAN`, `TEXT`…),
et `autoFilled=true` + `sourceMetadataKey` sont renseignés.

## Stockage JSON (H2)

Les colonnes `metadata`, `validationRules` et `value` sont persistées en JSON
via hypersistence-utils (`@Type(JsonType.class)`), compatible H2 et PostgreSQL.

## Snapshot historique

À l'enregistrement d'une annotation, chaque `AnnotationFieldValue` conserve un
instantané du champ (`fieldName`, `fieldLabel`, `fieldType`) pour garantir la
cohérence même si le formulaire évolue (les formulaires sont aussi versionnés).

## Réponse standardisée

Succès :
```json
{ "success": true, "data": { } }
```

Erreur :
```json
{ "success": false, "error": { "code": "PROJECT_NOT_FOUND", "message": "Project not found" } }
```

## Pagination

`GET /api/projects/{id}/images?page=0&size=20`
`GET /api/projects/{id}/annotations?page=0&size=20`
